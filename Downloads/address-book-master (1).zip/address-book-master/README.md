# address-book

##### JavaScript OO - Address Book

## Description

This application is a demonstration of constructors and prototypes using JavaScript to create a simple Address Book app.

## Setup

Install address-book by cloning this repository.

## Technologies Used

JavaScript and jQuery
